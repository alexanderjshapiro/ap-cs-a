import java.util.ArrayList;
import java.util.List;

/**
 * In this project you will gain more practice using the ArrayList class.
 * 
 * NOTE 1:
 *  Watch the types called for in each class carefully.
 *  Some use arrays and some use lists as parameters but NONE return an
 *  array.
 *  
 *  Just because a method takes an array as a parameter doesn't mean it
 *  that it can't return a List!
 * 
 * NOTE 2:
 *  A check the pre-conditions carefully. If a method says a parameter
 *  is unchanged then you must not modify the array or list specified
 *  in your method!
 * 
 * @author (your name) 
 * @version Unit 6
 */
public class MoreStringLists
{
    /**
     * Simply return your name as a String, last name then first name, separated by a comma
     *
     * @return your name as a String
     */
    public static String yourName()
    {
        return null; 
    }

    /**
     * Given a string, create a list with each element split at the comma in
     * the same relative order. 
     * 
     * For example:
     *  csv = "up,down,left,right,top,bottom"
     *  
     * would return:
     *  ["up","down","left","right","top","bottom"]
     * 
     * Precondition:    csv is not null
     *                  csv.length() > 0
     *                  at least one non-comma character appears before and
     *                  after each comma
     * @param   csv a string of comma separated values
     * @return  a list of each comma separated value
     */
    public static List<String> csvList(String csv)
    {
        return null; // Change this!  
    }  

    /**
     * Given a list of names, return true if the parameter name does NOT already.
     * appear in the list.
     * 
     * Precondition:    names is not null
     *                  names.size > 0
     *                  name is not null
     * Postcondition:   names is unchanged
     *                  
     * @param   names   a list of Strings that are names
     * @param   name    the name that may be in the list    
     * @return  true if name is not found in names and false if it is found
     */
    public static boolean isUnique(List<String> names, String name)
    {
        return false; // Change this!
    }

    /**
     * Given an array of names that may contain duplicates, return a list with no duplicates.
     * The names should be in the same relative order as found in the orginal array.
     * 
     * For example:
     *  {"Aaron", "Ken", "Gena", "Aaron", "Michael"}
     * would be reduced to:
     *  ["Aaron", "Ken", "Gena", "Michael"]
     * 
     * Precondition:    names is not null
     * Postcondition:   names is unchanged
     *                  
     * @param   names an array of names that may contain duplicates
     * @return  a list of names in the same relative order but with no duplicates
     */
    public static List<String> reduce(String[] names)
    {
        return null; // Change this!
    }

    /**
     * Given two Lists of Strings return a new list that contains names that appear in both of
     * the original lists.  
     * In other words, follow these guidelines:
     * Add each name from the first list to your new list only if it
     * found in the second list. Add strings to the new list in order
     * the order they are found in the first list (names1).
     * 
     * For example:
     *  names1 = ["Aaron", "Ken", "Gena", "Michael"]
     *  names2 = ["David", "Ken", "Aaron", "Jason"]
     *  
     * would be merged into:
     *  ["Aaron", "Ken"]
     *  
     * because "Aaron" is the first name in the first list that is also found
     * in the second list it is first in the resulting list!
     * 
     * Precondition:    names1 and names2 are not null
     *                  no elements are repeated more than once in names1
     *                  no elements are repeated more than once in names2
     *                  
     * Postcondition:   names1 and names2 are unchanged
     *                  
     * @param   names1 an a list of names (no duplicates)
     * @param   names2 anotbher list of names (no duplicates)
     * @return  the names that appear in both names1 and names2 in the relative
     *          order found in names1
     */
    public static List<String> mergeDups(List<String> names1, List<String> names2)
    {
        return null; // Change this!
    }

    /**
     * Given a String of all capital letters, return a list containing each
     * letter found in the string only once.
     * The list should be in alphabetical order. 
     *
     * HINT:    You can add elements to a list at any index so keep your list
     *          in alphabetical order as you make it!
     * 
     * For example:
     *  letters = "AARON"
     *  
     * would return:
     *  ["A", "N", "O", "R"]
     *      
     * even though the "A" is found twice it is in the list only once and the
     * remaining letters are in alphabetical order!
     * 
     * Precondition:    letters is not null
     *                  letters.length() > 0
     *                  all characters in letters are captialized
     *                  
     * @param   letters a string containing capital letters (may contain duplicates)
     * @return  each letter, once, found in letters arranged in alphabetical order
     */
    public static List<String> alphaOrder(String letters)
    {
        return null; // Change this
    }    
}

