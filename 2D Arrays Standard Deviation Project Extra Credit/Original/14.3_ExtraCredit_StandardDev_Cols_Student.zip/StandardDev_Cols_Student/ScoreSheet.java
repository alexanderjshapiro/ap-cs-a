
/**
 * Write a description of class ScoreSheet here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class ScoreSheet
{
     /**
     * This method will return an array that represents the average value of each column of the given 2D array.
     * 
     * @param   scores      2D array of scores
     * @return  averages    1D array representing the average of each column of scores
     */
    public static double[] calcAvgCol(double[][] scores)
    {
        // Your code goes here
        return null;// You MUST replace this!
    }

    /**
     * This method will return a 2 dimensional array that calculates the square of the difference
     * between the value
     * and the average of the column.  The average of the column was already calculated for you and passed 
     * in as a parameter.
     * You will do the calculation and store the result back into the same element of the scores 
     * array for which you 
     * are calculating the result.  At the end of the method, simply return the scores array.
     * 
     * @param   scores      2D array of scores
     * @param   average     1D array representing the average of each column of scores
     * @return  diffSquared 2D array
     */
    public static double[][] scoresLessMeanSquaredCols(double[][] scores, double[] average)
    {
        // Your code goes here
        return null;// You MUST replace this!
    }

    /**
     * This method will return an array that represents the standard deviation of the values in each column
     * given 2D array.
     * 
     * To caluclauate the standard deviation, perform the following steps:
     * 1: Use your calcAvg method to get the average value for each row
     * 2: Use your scoresLessMeanSquared method to calculate the square of the difference of each value 
     *     with the row's avarage
     * 3: Use your calAvg again to get the average of what was calculated in step 2.
     * 4: Calculate the square root of each value in the array returned by step 3.
     * 5: return the results of step 4.
     * 
     * @param   scores      2D array of scores
     * @return  stdDev      1D array representing the standard deviation in each column of scores.
     */    
    public static double[] stdDevCols(double[][] scores)
    {
        // Your code goes here
        return null;// You MUST replace this!
    }
}
